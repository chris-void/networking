#Readme

To run the client and the server, please use python3 client.py/server.py followed the right host or port info.

Code is tested on csa2.