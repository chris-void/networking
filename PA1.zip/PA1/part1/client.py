#!/usr/bin/env python3
#
# client.py - runs the experiments
#
# Shuwen Sun
# Oct 2015

import socket
import sys

# simple client
if __name__ == '__main__':
    HOST, PORT = sys.argv[1:3]
    data = bytes(' '.join(sys.argv[3:]) + '\n', 'utf8')
    with socket.create_connection((HOST, PORT)) as s:
        s.send(data)
        received = s.recv(1024)
    print("Sent:     %s" % data)
    print("Received: %s" % received)
