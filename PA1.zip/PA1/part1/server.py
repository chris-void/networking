#!/usr/bin/env python3
#
# client.py - runs the experiments
#
# Shuwen Sun
# Oct 2015

import socket
import socketserver
import sys

# use a handler to handle the request from the client to the server
class EchoHandler(socketserver.StreamRequestHandler):
    def handle(self):
        """
        Sends the data from the request back to the sending client.
        """
        self.data = self.rfile.readline().strip()
        self.wfile.write(self.data)

if __name__ == "__main__":
    HOST, PORT = socket.getfqdn(), int(sys.argv[1])
    server = socketserver.TCPServer((HOST, PORT), EchoHandler)
    server.serve_forever()
