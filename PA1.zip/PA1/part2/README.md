#Readme

**To compile**

For the client, please change the host and port in *config.py*. After that `python3 client.py` will start the program.

For the server, `python3 server.py <server port#>` will do the tricks.


## Results

The test I did is based on running the client on my laptop(Macintosh), and server on csa2. The results is stored in *data_file*.

For the anwser and explanation of plots, please see the pa1_report.pdf.